<?php
// ============================================================
// DASHBOARD.PHP — Vue principale du monitoring robots
// ============================================================
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config/config.php';
require_login();

$user = current_user();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard — <?= APP_NAME ?></title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body class="dash-body">

<!-- ========== TOPBAR ========== -->
<header class="topbar">
  <div class="topbar-left">
    <svg class="topbar-icon" width="28" height="28" viewBox="0 0 48 48" fill="none">
      <rect x="4" y="14" width="40" height="26" rx="3" stroke="#f59e0b" stroke-width="2"/>
      <rect x="14" y="4" width="20" height="10" rx="2" stroke="#f59e0b" stroke-width="2"/>
      <circle cx="16" cy="27" r="4" fill="#f59e0b"/>
      <circle cx="32" cy="27" r="4" fill="#f59e0b"/>
      <line x1="20" y1="27" x2="28" y2="27" stroke="#f59e0b" stroke-width="2"/>
    </svg>
    <span class="topbar-title">ROBOTRACK</span>
    <span class="topbar-version">v<?= APP_VERSION ?></span>
  </div>

  <div class="topbar-center">
    <span id="live-indicator" class="live-dot"></span>
    <span id="live-label">CONNECTING…</span>
    <span id="last-update" class="topbar-ts"></span>
  </div>

  <div class="topbar-right">
    <span class="topbar-user">
      <svg width="12" height="12" viewBox="0 0 12 12" fill="#94a3b8">
        <circle cx="6" cy="4" r="2.5"/>
        <path d="M1 11c0-2.76 2.24-5 5-5s5 2.24 5 5" stroke="#94a3b8" fill="none" stroke-width="1.2"/>
      </svg>
      <?= $user ?>
    </span>
    <a href="logout.php" class="btn-logout">LOGOUT</a>
  </div>
</header>

<!-- ========== MAIN LAYOUT ========== -->
<div class="dash-layout">

  <!-- ---- SIDEBAR ---- -->
  <aside class="sidebar">
    <div class="sidebar-header">FLEET STATUS</div>
    <div id="robot-list" class="robot-list">
      <!-- Peuplé par JS -->
      <div class="robot-list-loading">Initializing…</div>
    </div>

    <!-- Zone réservée batterie (future) -->
    <div class="sidebar-section">
      <div class="sidebar-header">BATTERY</div>
      <div id="battery-panel" class="battery-panel">
        <!-- TODO BATTERY MQTT : afficher ici les niveaux de batterie
             en temps réel depuis les topics MQTT robots/{id}/battery -->
        <p class="placeholder-text">Battery data via MQTT — coming soon</p>
      </div>
    </div>

    <!-- Zone réservée caméra (future) -->
    <div class="sidebar-section">
      <div class="sidebar-header">CAMERA FEED</div>
      <div id="camera-panel" class="camera-panel">
        <!-- TODO CAMERA STREAM : intégrer ici un <video> ou <img>
             pointant vers le stream MJPEG/WebRTC de la caméra top-view
             ex: <img src="http://cam-server/stream.mjpg"> -->
        <p class="placeholder-text">Top-view camera — coming soon</p>
      </div>
    </div>
  </aside>

  <!-- ---- MAP AREA ---- -->
  <main class="map-area">
    <div class="map-wrapper">
      <!-- Image du track (fond) -->
      <img
        id="track-bg"
        src="<?= htmlspecialchars(TRACK_IMAGE, ENT_QUOTES, 'UTF-8') ?>"
        alt="Track layout"
        class="track-image"
        draggable="false"
      >
      <!-- Canvas overlay pour les robots (même taille que l'image) -->
      <canvas id="robot-canvas" class="robot-canvas"></canvas>

      <!-- Tooltip -->
      <div id="robot-tooltip" class="robot-tooltip hidden"></div>
    </div>

    <!-- Barre de statut bas de map -->
    <div class="map-statusbar">
      <span id="robot-count">-- robots</span>
      <span id="active-count">-- active</span>
      <span class="map-source">SOURCE: <?= strtoupper(DATA_SOURCE) ?></span>
      <span id="poll-status"></span>
    </div>
  </main>

</div><!-- /.dash-layout -->

<!-- Config passée au JS via data attributes (pas de secrets) -->
<div
  id="js-config"
  data-poll="<?= POLL_INTERVAL_MS ?>"
  data-api="api/robots.php"
  hidden
></div>

<script src="assets/app.js"></script>
</body>
</html>
