<?php
// ============================================================
// INCLUDES/AUTH.PHP — Gestion session & protection des routes
// ============================================================

require_once __DIR__ . '/../config/config.php';

function session_start_secure(): void {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.cookie_samesite', 'Strict');
    ini_set('session.gc_maxlifetime', SESSION_LIFETIME);
    session_name(SESSION_NAME);
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
}

function is_logged_in(): bool {
    session_start_secure();
    return isset($_SESSION['user'])
        && isset($_SESSION['expires'])
        && $_SESSION['expires'] > time();
}

function require_login(): void {
    if (!is_logged_in()) {
        header('Location: login.php');
        exit;
    }
    // Prolonge la session à chaque requête active
    $_SESSION['expires'] = time() + SESSION_LIFETIME;
}

function attempt_login(string $username, string $password): bool {
    session_start_secure();
    if (
        $username === ADMIN_USERNAME
        && password_verify($password, ADMIN_PASSWORD_HASH)
    ) {
        session_regenerate_id(true); // Prévient la fixation de session
        $_SESSION['user']    = $username;
        $_SESSION['expires'] = time() + SESSION_LIFETIME;
        return true;
    }
    return false;
}

function logout(): void {
    session_start_secure();
    $_SESSION = [];
    session_destroy();
}

function current_user(): string {
    return htmlspecialchars($_SESSION['user'] ?? 'Unknown', ENT_QUOTES, 'UTF-8');
}

// --- TODO (extensibilité) ---
// Pour ajouter des rôles (admin / viewer / operator) :
//   $_SESSION['role'] = 'admin';
// Puis créer require_role('admin') qui vérifie $_SESSION['role'].
