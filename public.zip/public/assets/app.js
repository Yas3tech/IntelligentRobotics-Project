// ============================================================
// ASSETS/APP.JS — RoboTrack Monitor frontend
// ============================================================
// Vanilla JS, aucune dépendance externe.
// ============================================================

(() => {
  'use strict';

  // --- Config depuis le DOM ---
  const cfg       = document.getElementById('js-config');
  const POLL_MS   = parseInt(cfg.dataset.poll, 10) || 500;
  const API_URL   = cfg.dataset.api;

  // --- DOM refs ---
  const canvas     = document.getElementById('robot-canvas');
  const ctx        = canvas.getContext('2d');
  const trackImg   = document.getElementById('track-bg');
  const robotList  = document.getElementById('robot-list');
  const tooltip    = document.getElementById('robot-tooltip');
  const liveLabel  = document.getElementById('live-label');
  const liveDot    = document.getElementById('live-indicator');
  const lastUpdate = document.getElementById('last-update');
  const robotCount = document.getElementById('robot-count');
  const activeCount= document.getElementById('active-count');
  const pollStatus = document.getElementById('poll-status');

  // --- State ---
  let robots         = [];
  let selectedRobotId= null;
  let errorCount     = 0;
  let animFrame      = null;

  // --- Couleurs par statut ---
  const STATUS_COLORS = {
    active : '#22c55e',
    idle   : '#f59e0b',
    error  : '#ef4444',
    offline: '#64748b',
    unknown: '#94a3b8',
  };

  // ============================================================
  // RESIZE CANVAS : toujours aligné sur l'image de fond
  // ============================================================
  function syncCanvasSize() {
    const rect = trackImg.getBoundingClientRect();
    if (canvas.width !== rect.width || canvas.height !== rect.height) {
      canvas.width  = rect.width;
      canvas.height = rect.height;
    }
    // Dimensions naturelles de l'image (pour la mise à l'échelle des coords)
    canvas._naturalW = trackImg.naturalWidth  || rect.width;
    canvas._naturalH = trackImg.naturalHeight || rect.height;
    canvas._dispW    = rect.width;
    canvas._dispH    = rect.height;
  }

  // ============================================================
  // COORD MAPPING : les JSON x/y sont en pixels de l'image source
  // On les re-scale selon la taille d'affichage courante.
  // ============================================================
  function toDisplay(x, y) {
    const scaleX = canvas._dispW  / canvas._naturalW;
    const scaleY = canvas._dispH  / canvas._naturalH;
    return { dx: x * scaleX, dy: y * scaleY };
  }

  // ============================================================
  // DRAW — un robot sur le canvas
  // ============================================================
  const ROBOT_RADIUS   = 12;
  const ARROW_LENGTH   = 22;
  const ARROW_HEAD     = 6;
  const LABEL_OFFSET_Y = 20;

  function drawRobot(r, isSelected) {
    const { dx, dy } = toDisplay(r.x, r.y);
    const color      = STATUS_COLORS[r.status] || STATUS_COLORS.unknown;
    const headRad    = (r.heading - 90) * (Math.PI / 180); // 0° = North → -90° offset

    ctx.save();
    ctx.translate(dx, dy);

    // --- Halo sélection ---
    if (isSelected) {
      ctx.beginPath();
      ctx.arc(0, 0, ROBOT_RADIUS + 6, 0, Math.PI * 2);
      ctx.strokeStyle = color;
      ctx.lineWidth   = 1.5;
      ctx.globalAlpha = 0.4;
      ctx.stroke();
      ctx.globalAlpha = 1;
    }

    // --- Corps du robot ---
    ctx.beginPath();
    ctx.arc(0, 0, ROBOT_RADIUS, 0, Math.PI * 2);
    ctx.fillStyle   = '#0f172a';
    ctx.strokeStyle = color;
    ctx.lineWidth   = 2;
    ctx.fill();
    ctx.stroke();

    // --- Flèche de direction (heading) ---
    const arrowTipX = Math.cos(headRad) * ARROW_LENGTH;
    const arrowTipY = Math.sin(headRad) * ARROW_LENGTH;

    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(arrowTipX, arrowTipY);
    ctx.strokeStyle = color;
    ctx.lineWidth   = 2;
    ctx.lineCap     = 'round';
    ctx.stroke();

    // Pointe de flèche
    const backAngle = headRad + Math.PI;
    const leftX  = arrowTipX + Math.cos(backAngle - 0.45) * ARROW_HEAD;
    const leftY  = arrowTipY + Math.sin(backAngle - 0.45) * ARROW_HEAD;
    const rightX = arrowTipX + Math.cos(backAngle + 0.45) * ARROW_HEAD;
    const rightY = arrowTipY + Math.sin(backAngle + 0.45) * ARROW_HEAD;

    ctx.beginPath();
    ctx.moveTo(arrowTipX, arrowTipY);
    ctx.lineTo(leftX, leftY);
    ctx.lineTo(rightX, rightY);
    ctx.closePath();
    ctx.fillStyle = color;
    ctx.fill();

    // --- Label ---
    ctx.font         = 'bold 9px "JetBrains Mono", "Courier New", monospace';
    ctx.textAlign    = 'center';
    ctx.textBaseline = 'top';
    // Fond du label
    const lw = ctx.measureText(r.label).width + 6;
    ctx.fillStyle = 'rgba(0,0,0,0.75)';
    ctx.fillRect(-lw / 2, LABEL_OFFSET_Y - 1, lw, 12);
    ctx.fillStyle = color;
    ctx.fillText(r.label, 0, LABEL_OFFSET_Y);

    ctx.restore();
  }

  // ============================================================
  // RENDER — redessine tout le canvas
  // ============================================================
  function render() {
    syncCanvasSize();
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    robots.forEach(r => drawRobot(r, r.id === selectedRobotId));
  }

  // ============================================================
  // SIDEBAR — liste des robots
  // ============================================================
  function updateSidebar() {
    robotList.innerHTML = '';
    if (!robots.length) {
      robotList.innerHTML = '<div class="robot-list-loading">No robots detected</div>';
      return;
    }

    robots.forEach(r => {
      const color   = STATUS_COLORS[r.status] || STATUS_COLORS.unknown;
      const batHtml = r.battery >= 0
        ? `<div class="robot-bat">
             <div class="bat-bar">
               <div class="bat-fill" style="width:${r.battery}%; background:${batteryColor(r.battery)}"></div>
             </div>
             <span>${r.battery}%</span>
           </div>`
        : '';

      const item = document.createElement('div');
      item.className = 'robot-item' + (r.id === selectedRobotId ? ' selected' : '');
      item.dataset.id = r.id;
      item.innerHTML = `
        <div class="robot-item-header">
          <span class="robot-dot" style="background:${color}"></span>
          <span class="robot-label">${esc(r.label)}</span>
          <span class="robot-status">${esc(r.status)}</span>
        </div>
        <div class="robot-coords">
          X:${Math.round(r.x)} Y:${Math.round(r.y)} HDG:${Math.round(r.heading)}°
        </div>
        ${batHtml}
      `;
      item.addEventListener('click', () => {
        selectedRobotId = (selectedRobotId === r.id) ? null : r.id;
        updateSidebar();
        render();
      });
      robotList.appendChild(item);
    });

    // Stats
    const activeN = robots.filter(r => r.status === 'active').length;
    robotCount.textContent  = `${robots.length} robots`;
    activeCount.textContent = `${activeN} active`;
  }

  function batteryColor(pct) {
    if (pct > 50) return '#22c55e';
    if (pct > 20) return '#f59e0b';
    return '#ef4444';
  }

  // ============================================================
  // FETCH — polling AJAX
  // ============================================================
  async function fetchRobots() {
    try {
      const res  = await fetch(API_URL, { credentials: 'same-origin' });
      if (res.status === 401) { window.location.href = 'login.php'; return; }
      if (!res.ok) throw new Error(`HTTP ${res.status}`);

      const data = await res.json();
      robots     = data.robots || [];
      errorCount = 0;

      // UI feedback
      setLiveStatus('live');
      const d = new Date(data.ts * 1000);
      lastUpdate.textContent = d.toLocaleTimeString();
      pollStatus.textContent = '';

      updateSidebar();

    } catch (err) {
      errorCount++;
      setLiveStatus('error');
      pollStatus.textContent = `ERR×${errorCount}`;
      console.warn('[RoboTrack] fetch error:', err);
    }

    render();
  }

  function setLiveStatus(state) {
    liveDot.className  = 'live-dot ' + state;
    liveLabel.textContent = state === 'live'  ? 'LIVE'
                           : state === 'error' ? 'RECONNECTING…'
                           : 'CONNECTING…';
  }

  // ============================================================
  // TOOLTIP on canvas hover
  // ============================================================
  canvas.addEventListener('mousemove', (e) => {
    const rect = canvas.getBoundingClientRect();
    const mx   = e.clientX - rect.left;
    const my   = e.clientY - rect.top;

    let found = null;
    for (const r of robots) {
      const { dx, dy } = toDisplay(r.x, r.y);
      const dist = Math.hypot(mx - dx, my - dy);
      if (dist < ROBOT_RADIUS + 8) { found = r; break; }
    }

    if (found) {
      tooltip.innerHTML = `
        <strong>${esc(found.label)}</strong>
        <span>Status: ${esc(found.status)}</span>
        <span>X: ${found.x}  Y: ${found.y}</span>
        <span>Heading: ${found.heading}°</span>
        ${found.battery >= 0 ? `<span>Battery: ${found.battery}%</span>` : ''}
      `;
      tooltip.classList.remove('hidden');
      tooltip.style.left = (e.clientX - rect.left + 16) + 'px';
      tooltip.style.top  = (e.clientY - rect.top  - 10) + 'px';
      canvas.style.cursor = 'pointer';
    } else {
      tooltip.classList.add('hidden');
      canvas.style.cursor = 'crosshair';
    }
  });

  canvas.addEventListener('mouseleave', () => {
    tooltip.classList.add('hidden');
  });

  canvas.addEventListener('click', (e) => {
    const rect = canvas.getBoundingClientRect();
    const mx   = e.clientX - rect.left;
    const my   = e.clientY - rect.top;

    let found = null;
    for (const r of robots) {
      const { dx, dy } = toDisplay(r.x, r.y);
      if (Math.hypot(mx - dx, my - dy) < ROBOT_RADIUS + 8) { found = r; break; }
    }
    selectedRobotId = found ? (selectedRobotId === found.id ? null : found.id) : null;
    updateSidebar();
    render();
  });

  // ============================================================
  // INIT
  // ============================================================
  function esc(str) {
    const d = document.createElement('div');
    d.appendChild(document.createTextNode(String(str)));
    return d.innerHTML;
  }

  // Attendre que l'image soit chargée avant le premier rendu
  if (trackImg.complete) {
    syncCanvasSize();
    fetchRobots();
  } else {
    trackImg.addEventListener('load', () => {
      syncCanvasSize();
      fetchRobots();
    });
  }

  // Resync canvas si la fenêtre est redimensionnée
  window.addEventListener('resize', () => {
    syncCanvasSize();
    render();
  });

  // Polling régulier
  setInterval(fetchRobots, POLL_MS);

  // ============================================================
  // TODO MQTT/WebSocket : remplacer setInterval(fetchRobots) par :
  //
  //   const ws = new WebSocket('wss://votre-serveur/ws');
  //   ws.onmessage = (e) => {
  //     const data = JSON.parse(e.data);
  //     robots = data.robots;
  //     updateSidebar(); render();
  //   };
  //
  // Garder le polling en fallback si WS se déconnecte.
  // ============================================================

})();
