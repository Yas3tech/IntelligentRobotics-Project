<?php
// ============================================================
// CONFIG — robot-monitor MVP
// ============================================================
// Ne jamais committer ce fichier avec de vrais mots de passe.
// Sur un vrai déploiement, utiliser des variables d'environnement
// ou un fichier .env hors du webroot.
// ============================================================

define('APP_NAME', 'RoboTrack Monitor');
define('APP_VERSION', '1.0.0');

// --- Auth ---
// Générer un nouveau hash : php -r "echo password_hash('votre_mdp', PASSWORD_BCRYPT);"
define('ADMIN_USERNAME', 'admin');
define('ADMIN_PASSWORD_HASH', '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'); // "password"

// --- Session ---
define('SESSION_NAME', 'robotrack_sess');
define('SESSION_LIFETIME', 3600); // 1h en secondes

// --- Data source ---
// 'mock'  => lit data/robots_mock.json
// 'file'  => lit data/robots_live.json  (écrit par un script externe / signaling server)
// 'api'   => appelle une URL externe (voir api/robots.php)
define('DATA_SOURCE', 'mock');
define('DATA_SOURCE_URL', 'http://localhost:9000/robots'); // utilisé si DATA_SOURCE = 'api'

// --- Polling interval (ms) ---
define('POLL_INTERVAL_MS', 500);

// --- Track image ---
// Mettre votre image dans assets/ et changer le chemin ici
define('TRACK_IMAGE', 'assets/track.svg'); // SVG placeholder par défaut

// --- Timezone ---
date_default_timezone_set('Europe/Brussels');
